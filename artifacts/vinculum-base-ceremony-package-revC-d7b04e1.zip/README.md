# Vinculum Base-only ceremony package (registry Revision C, main d7b04e1)

This package holds the files for the Vinculum Base-only ceremony, taken unchanged from the main branch of VinculumDefi/Finalis-Launch at commit d7b04e1.

## Registry

- Registry: Revision C, `base-contracts/deployment/assetRegistry.revC.json`, SHA-256 `5c3311eb4f7b59c34e7ccc8a6bd9e817b4f0bb02bdeff65c5cfed98f79cca581`.
- Revision C is a full copy of Revision B with one change: row 454 Base USDC is S1. Revision B is included only because the manifest pins it as the record of the finalized Oct 22 set. It is not the ceremony source.
- Ceremony manifest SHA-256: `9f84a11f1905fdc450b3d5fc6d482b238b739d3ef91ff22f571cff3ec4b75689`.

## What the ceremony registers

27 Base rows:

- Native ETH, row 2, class S2 at 1.3x.
- Base USDC, row 454, class S1 at 1.5x.
- 25 other ERC-20 rows, class S3 at 1.0x.

Base USDT is not in this package.

## ETH price

The ETH price is retained from the build. It was not refreshed and does not need to be refreshed before the ceremony.

## Dry-run

The dry-run ran on a local Base fork with a simulated signer. Nothing was broadcast. It ended with reconciliation PASS, and a 1000 USDC 7-day lock minted 15,000 VCLM (it would be 10,000 VCLM at S3).

## Files and SHA-256

All paths are relative to the repository root. `SHA256SUMS.txt` in this archive lists the same hashes in checksum format.

- `base-contracts/deployment/CEREMONY_CHECKLIST_2026-10-21.md`  
  SHA-256 `677ec9bacf0aa4581a7fbf4da7388942c7465d8dbdefc55c093192321a3e3e0e`
- `base-contracts/deployment/DEPLOYMENT_DAY_RUNBOOK.md`  
  SHA-256 `642d84a535a858d3c0057da7354c75f2dfaf4f0083ccd2e41923da50ce042ab8`
- `base-contracts/deployment/LIVE_DEPLOYMENT_ORDER.md`  
  SHA-256 `045f608a8ec761c827139fa518154ac6eeaaef59efbd148a229a2cb1a8641a31`
- `base-contracts/deployment/assetRegistry.revB.json`  
  SHA-256 `1bdcb8346ab95abe5225adcffb9c5c3c7bb40c6cd5f1a851d3ed05bb2d77e2a9`
- `base-contracts/deployment/assetRegistry.revC.json`  
  SHA-256 `5c3311eb4f7b59c34e7ccc8a6bd9e817b4f0bb02bdeff65c5cfed98f79cca581`
- `base-contracts/deployment/ceremony-manifest.json`  
  SHA-256 `9f84a11f1905fdc450b3d5fc6d482b238b739d3ef91ff22f571cff3ec4b75689`
- `base-contracts/deployment/liveConfig.json`  
  SHA-256 `77bc0228aa2aa70df8e631f795d6cc7d1c9ad74f75ca620c8d097bf68b33e5ac`
- `base-contracts/deployment/representativeBase.cjs`  
  SHA-256 `fe533f821c52b828e22e6b6e5a0ea4b3b88d6dfbc3907973362eab6f7557c855`
- `base-contracts/scripts/deploy-pages/README.md`  
  SHA-256 `aa29171730750eb47eddb9a2a30978d523644758906ab62a78f14053f448f30d`
- `base-contracts/scripts/deploy-pages/base.html`  
  SHA-256 `50d08f3064c75db97eaeb2e710a43fbe1fa0a0b3ee2546d7513014803a35998a`
- `base-contracts/scripts/deploy-pages/baseCeremonyFlow.js`  
  SHA-256 `d2e1de2dd50fa870642be09f00a8a3d5fe130fa68038cbd8a7dbd46d215992c5`
- `base-contracts/scripts/deploy-pages/ceremony-data.json`  
  SHA-256 `9353418e9b541a997c4831c07361fe15c1e6f65f7d679e6f20f0ab2cab0ba0a3`
- `base-contracts/scripts/deploy-pages/ceremony.json`  
  SHA-256 `d1477e9596f11bd86cf16faef544f505a257046412771a634f5a2cd779cef5c5`

## Signing

The founder signs, broadcasts and finalizes. Nothing in this package contains keys, seed phrases or passwords.
